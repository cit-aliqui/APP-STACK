package com.rdp.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleFeaturAssociation implements Serializable {

	private static final long serialVersionUID = -1659830127751963880L;
	private Integer roleFeatureAssociateId;
	private Integer roleId;
	private Integer featureId;
	private String featureName;
	private Integer subFeatureId;
	private String subFeatureName;

	public Integer getFeatureId() {
		return featureId;
	}

	public void setFeatureId(Integer featureId) {
		this.featureId = featureId;
	}

	public Integer getRoleFeatureAssociateId() {
		return roleFeatureAssociateId;
	}

	public void setRoleFeatureAssociateId(Integer roleFeatureAssociateId) {
		this.roleFeatureAssociateId = roleFeatureAssociateId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getFeatureName() {
		return featureName;
	}

	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}

	
	public Integer getSubFeatureId() {
		return subFeatureId;
	}

	public void setSubFeatureId(Integer subFeatureId) {
		this.subFeatureId = subFeatureId;
	}

	public String getSubFeatureName() {
		return subFeatureName;
	}

	public void setSubFeatureName(String subFeatureName) {
		this.subFeatureName = subFeatureName;
	}
	

}
