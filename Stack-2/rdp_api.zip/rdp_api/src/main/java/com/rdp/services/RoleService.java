package com.rdp.services;

import java.util.List;

import com.rdp.domain.Feature;
import com.rdp.domain.Role;
import com.rdp.exception.RDPException;

public interface RoleService {

	public List<Feature> getFeatures(Integer roleId) throws Exception;
	
	public Integer saveRole(Role role)throws RDPException;
	public Integer updateRole(Role role)throws RDPException;
	public Integer deleteRole(Integer roleId)throws RDPException;
	public Role getRoleById(Integer roleId)throws RDPException;
	public List<Role> getRoles()throws RDPException;

}
