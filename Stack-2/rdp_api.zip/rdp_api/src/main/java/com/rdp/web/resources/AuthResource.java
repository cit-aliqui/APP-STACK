package com.rdp.web.resources;


import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rdp.exception.RDPException;
import com.rdp.rest.response.ErrorResponse;

@RestController
@RequestMapping("/unauthorized")
public class AuthResource {


     
 
    @RequestMapping(
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ErrorResponse> exceptionHandler() throws RDPException{
    	ErrorResponse error;
		try {
			error = new ErrorResponse();
			error.setErrorCode("ERR_2001");
			error.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
			error.setErrorMessage("Unauthorized");
		} catch (Exception e) {
			throw new RDPException(HttpStatus.BAD_REQUEST.value(), "Unauthorized");
		}
		
		return new ResponseEntity<ErrorResponse>(error, HttpStatus.UNAUTHORIZED);
	}
}
