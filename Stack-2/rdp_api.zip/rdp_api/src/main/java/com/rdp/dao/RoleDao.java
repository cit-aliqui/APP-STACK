package com.rdp.dao;

import java.util.List;

import com.rdp.domain.Feature;
import com.rdp.domain.Role;
import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;

public interface RoleDao {
	
	public Integer saveRole(Role role)throws RDPException;
	public Integer updateRole(Role role)throws RDPException;
	public Integer deleteRole(Integer roleId)throws RDPException;
	public Role getRoleById(Integer roleId)throws RDPException;
	public List<Role> getRoles()throws RDPException;
	public List<Feature> getFeaturesbyroleId(Integer roleId) throws RDPException;
	
	public List<SubFeatures> getSubFeaturesbyfeatureId(Integer featureId, Integer roleId) throws RDPException;

}
