package com.rdp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.SubFeatureDAO;
import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;

@Repository
@Transactional
public class SubFeatureDAOImpl implements SubFeatureDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Environment environment;
	@Override
	public List<SubFeatures> getSubFeatures() throws RDPException {
		String query=null;
		List<SubFeatures> feature=null;
		
		
		query=environment.getProperty("SELECT_SUB_FEATURE");
		
		feature=jdbcTemplate.query(query,this::matchRows);
		
		return feature;
	}
	
	
	private SubFeatures matchRows(ResultSet rs,int rowNumber) throws SQLException {
		SubFeatures sf=new SubFeatures();
		sf.setFeatureId(rs.getInt("Feature_Id"));
		sf.setSubFeatureId(rs.getInt("Sub_Feature_Id"));
		sf.setSubFeatureName(rs.getString("Sub_Feature_Name"));
		sf.setSubFeatureDesc(rs.getString("Sub_Feature_Desc"));
		sf.setSubFeatureURL(rs.getString("Sub_Feature_URL"));
		
		return sf;
	}



	
}
