package com.rdp.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubFeatures {
	private Integer subFeatureId;
	private String subFeatureName;
	private String subfeaturedescription;
	private String subFeatureDesc;
	private String subFeatureURL;
	private Integer featureId;
	private ErrorResp errorResponse;

	public Integer getSubFeatureId() {
		return subFeatureId;
	}

	public void setSubFeatureId(Integer subFeatureId) {
		this.subFeatureId = subFeatureId;
	}

	public String getSubFeatureName() {
		return subFeatureName;
	}

	public void setSubFeatureName(String subFeatureName) {
		this.subFeatureName = subFeatureName;
	}

	public String getSubfeaturedescription() {
		return subfeaturedescription;
	}

	public void setSubfeaturedescription(String subfeaturedescription) {
		this.subfeaturedescription = subfeaturedescription;
	}

	public String getSubFeatureDesc() {
		return subFeatureDesc;
	}

	public void setSubFeatureDesc(String subFeatureDesc) {
		this.subFeatureDesc = subFeatureDesc;
	}

	public String getSubFeatureURL() {
		return subFeatureURL;
	}

	public void setSubFeatureURL(String subFeatureURL) {
		this.subFeatureURL = subFeatureURL;
	}

	public Integer getFeatureId() {
		return featureId;
	}

	public void setFeatureId(Integer featureId) {
		this.featureId = featureId;
	}

	public ErrorResp getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(ErrorResp errorResponse) {
		this.errorResponse = errorResponse;
	}

}
