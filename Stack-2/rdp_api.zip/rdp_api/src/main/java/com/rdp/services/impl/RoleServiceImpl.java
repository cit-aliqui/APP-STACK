package com.rdp.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.RoleDao;
import com.rdp.dao.RoleFeatureAssociationDao;
import com.rdp.domain.Feature;
import com.rdp.domain.Role;
import com.rdp.domain.RoleFeaturAssociation;
import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;
import com.rdp.services.RoleService;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleDao roleDao;

	@Autowired
	private RoleFeatureAssociationDao roleFeatureAssociationDao;

	@Override
	public Integer saveRole(Role role) throws RDPException {
		Integer result = null;
		List<Object[]> paramsList = null;

		paramsList = new ArrayList<>();
		try {
			result = roleDao.saveRole(role);
			
			if(role.getFeatureList() !=null && role.getFeatureList().size()>0)
			{
			for (Feature f : role.getFeatureList()) {
				paramsList.add(new Object[] { result, f.getFeatureId(),f.getSubFeatureId() });
			}
			
			roleFeatureAssociationDao.batchUpdate(paramsList);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public Integer updateRole(Role role) throws RDPException {
		Integer result = null;
		List<Object[]> paramsList = null;

		paramsList = new ArrayList<>();

		try {
			result = roleDao.updateRole(role);
			roleFeatureAssociationDao.deleteRoleFeatureAssocitation(role.getRoleId());
			if(role.getFeatureList() !=null && role.getFeatureList().size()>0)
			{

			for (Feature f : role.getFeatureList()) {

				paramsList.add(new Object[] { role.getRoleId(), f.getFeatureId(),f.getSubFeatureId() });
			}
			roleFeatureAssociationDao.batchUpdate(paramsList);

		} 
		}catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public Role getRoleById(Integer roleId) throws RDPException {
		Role role = null;
		List<RoleFeaturAssociation> rfAssociationList;
		List<Feature> fetureList = null;

		fetureList = new ArrayList<>();
		try {
			role = roleDao.getRoleById(roleId);

			
			rfAssociationList = roleFeatureAssociationDao.getRoleFeatureAssociationById(role.getRoleId());

			for (RoleFeaturAssociation rf : rfAssociationList) {
				Feature f = new Feature();
				f.setFeatureId(rf.getFeatureId());
				f.setFeatureName(rf.getFeatureName());
				f.setSubFeatureId(rf.getSubFeatureId());
				f.setSubFeatureName(rf.getSubFeatureName());
				fetureList.add(f);

			}

			role.setFeatureList(fetureList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}

		return role;
	}

	@Override
	public Integer deleteRole(Integer roleId) throws RDPException {

		Integer result = null;
		try {
			result = roleDao.deleteRole(roleId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public List<Role> getRoles() throws RDPException {
		List<Role> rolesList = null;
		List<RoleFeaturAssociation> rfAssociationList=new ArrayList<>();
		
		try {
			rolesList = roleDao.getRoles();

			/*
			 * If role is empty then return status by throwing exception.
			 */
			if (rolesList.isEmpty()) {
				throw new RDPException(HttpStatus.OK.value(), "Roles list not found");
			}

		
			for(int i=0;i<rolesList.size();i++)
			{
				List<Feature> fetureList = new ArrayList<>();
				rfAssociationList = roleFeatureAssociationDao.getRoleFeatureAssociationById(rolesList.get(i).getRoleId());
				if(rfAssociationList.size()>0)
				{
					for(int j=0;j<rfAssociationList.size();j++)
					{
						

						Feature f = new Feature();
						f.setFeatureId(rfAssociationList.get(j).getFeatureId());
						f.setFeatureName(rfAssociationList.get(j).getFeatureName());
						f.setSubFeatureId(rfAssociationList.get(j).getSubFeatureId());
						f.setSubFeatureName(rfAssociationList.get(j).getSubFeatureName());	
						fetureList.add(f);
					}
					
					
				}
				rolesList.get(i).setFeatureList(fetureList);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return rolesList;
	}

	@Override
	public List<Feature> getFeatures(Integer roleId) throws Exception {
		List<Feature> fetureList = null;
		try {
			fetureList = new ArrayList<>();
			List<SubFeatures> subfeatureList = new ArrayList<>();
			if (roleId != null) {
				fetureList = roleDao.getFeaturesbyroleId(roleId);
				if (fetureList != null && fetureList.size() > 0) {
					for (int i = 0; i < fetureList.size(); i++) {
						subfeatureList = roleDao.getSubFeaturesbyfeatureId(fetureList.get(i).getFeatureId(),roleId);
						fetureList.get(i).setSubFeatures(subfeatureList);
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return fetureList;
	}
}
