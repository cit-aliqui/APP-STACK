package com.rdp.dao;

import java.util.List;

import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;

public interface SubFeatureDAO {
	public List<SubFeatures> getSubFeatures()throws RDPException;
}
