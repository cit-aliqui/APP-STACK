package com.rdp.web.resources;

import java.net.URISyntaxException;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rdp.domain.Feature;
import com.rdp.domain.ResponseData;
import com.rdp.exception.RDPException;
import com.rdp.rest.response.SuccessResponse;
import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.AuthorizationToken;
import com.rdp.services.FeatureService;
import com.rdp.utils.RDPConfig;

@RestController
@RequestMapping("/feature")
public class FeatureResource {

	private SuccessResponse<Feature> successResponse;

	private ResponseData<Feature> responseData;
	Logger logger = LoggerFactory.getLogger(FeatureResource.class);
	@Autowired
	private AuthTokenStore authTokenStore;

	@Autowired
	private FeatureService featureService;

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Feature>> saveFeature(@RequestBody Feature feature,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;

		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = featureService.saveFeature(feature);
				if (count != null && count > 0) {

					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CREATED.value());
					responseData.setMessage("Feature details Saved Successfully");
					
					logger.info("user with id {} saved Feature with Feature id {}", auth.getUser().getCreatedBy(), count);

				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.CONFLICT.value());
					responseData.setMessage("Feature details failed to save");
					
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {

			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {
			
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			if (e.getMessage().contains("Name_UNIQUE")) {
				responseData.setMessage("Feature details already exists");
			} else {
				responseData.setMessage("Failed to Save Feature details");
			}
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Feature>>(successResponse, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Feature>> updateFeature(@RequestBody Feature feature,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = featureService.updateFeature(feature);
				
				if (count != null && count > 0) {
					successResponse.setHttpStatus(HttpStatus.OK.value());
					successResponse.setStatus(Boolean.TRUE);
					responseData.setMessage("Feature details Updated Successfully");
					logger.info("user with id {} updated Feature with Feature id {}", auth.getUser().getCreatedBy(), feature.getFeatureId());

				} else {
					successResponse.setHttpStatus(HttpStatus.OK.value());
					successResponse.setStatus(Boolean.TRUE);
					responseData.setMessage("Feature details are failed to udpate");
					
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {
			
			successResponse.setHttpStatus(e.getErrorCode());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage(e.getErrorMessage());
		} catch (Exception e) {
			
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			successResponse.setStatus(Boolean.FALSE);
			responseData.setMessage("Failed to update the fetture details");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Feature>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Feature>> getFeaturebyId(@PathVariable("id") Integer featureId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		Feature feature = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();

		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				feature = featureService.getFeatureById(featureId);
				if (feature != null) {
					responseData.setObject(feature);
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());

				} else {
					responseData.setMessage("Feature details not found");
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());

				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());
			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found with this id");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Feature>>(successResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Feature>> getCategories(@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken) throws URISyntaxException {
		List<Feature> featureList = null;
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				featureList = featureService.getFeatures();
				
				if (featureList.isEmpty()) {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setMessage("No Records found");
					
				} else {
					successResponse.setStatus(Boolean.TRUE);
					successResponse.setHttpStatus(HttpStatus.OK.value());
					responseData.setObjects(featureList);
				}
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
		} catch (RDPException e) {
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());

		} catch (Exception e) {
			successResponse = new SuccessResponse<>();
			responseData = new ResponseData<>();
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("No Records found");
		}
		successResponse.setData(responseData);

		return new ResponseEntity<SuccessResponse<Feature>>(successResponse, HttpStatus.OK);

	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public <T> ResponseEntity<SuccessResponse<Feature>> deleteFeature(@PathVariable("id") Integer featureId,
			@Valid @RequestHeader(required = true, value = RDPConfig.AUTH_TOKEN) String authToken)
			throws URISyntaxException {
		successResponse = new SuccessResponse<>();
		responseData = new ResponseData<>();
		Integer count = 0;
		try {
			AuthorizationToken auth = authTokenStore.retrieveToken(authToken);
			if (null != auth) {
				count = featureService.deleteFeature(featureId);
				successResponse.setHttpStatus(HttpStatus.OK.value());
				successResponse.setStatus(Boolean.TRUE);

				if (count != null && count > 0) {
					responseData.setMessage("Feature details deleted Successfully");
				} else {
					responseData.setMessage("No record found to delete with id :" + featureId);
				}
				successResponse.setData(responseData);
			} else {
				successResponse.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
				responseData.setMessage("Invalid Authentication Token");
				successResponse.setData(responseData);
			}
			
		} catch (RDPException e) {
			successResponse.setData(responseData);
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(e.getErrorCode());
			responseData.setMessage(e.getErrorMessage());
			
			successResponse.setData(responseData);
		} catch (Exception e) {
			successResponse.setData(responseData);
			successResponse.setStatus(Boolean.FALSE);
			successResponse.setHttpStatus(HttpStatus.PRECONDITION_REQUIRED.value());
			responseData.setMessage("Failed to deleted the feature details");
			successResponse.setData(responseData);
		}
		return new ResponseEntity<SuccessResponse<Feature>>(successResponse, HttpStatus.OK);
	}
}
