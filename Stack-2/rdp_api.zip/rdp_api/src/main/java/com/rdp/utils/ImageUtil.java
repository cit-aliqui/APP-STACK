package com.rdp.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;


import org.apache.commons.codec.binary.Base64;



public class ImageUtil {

	public static String encodeBase64(byte[] content) {

		return Base64.encodeBase64String(content);

	}

	/**
	 * Decode the image and return byte array.
	 * 
	 * @param imageDataString
	 * @return byte array.
	 */
	public static byte[] decodeImage(String imageDataString) {
		return Base64.decodeBase64(imageDataString);
	}

	public static String saveImage(String path, String imageName, String extention, String imageData) {
		
		FileOutputStream imageOutFile = null;
		String fullFileName = null;
		String fileName=null;
		
		try {
			fileName = imageName + "_" + new Date().getTime() + "." + extention;
			fullFileName = path + fileName;
			
			File myFile=new File(fullFileName);
			
			File parentDir = myFile.getParentFile();
			  if(! parentDir.exists()) 
			      parentDir.mkdirs();
			
			imageOutFile = new FileOutputStream(myFile);
			byte[] imageByteArray = decodeImage(imageData);
			imageOutFile.write(imageByteArray);
			imageOutFile.close();

		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		return fileName;
	}

	public static String retrieveImage(String filePath) {

		FileInputStream imageInFile = null;
		byte[] imageData = null;
		File file = null;

		if (filePath != null) {

			try {
				file = new File(filePath);

				imageInFile = new FileInputStream(file);
				imageData = new byte[(int) file.length()];
				imageInFile.read(imageData);

			} catch (FileNotFoundException e) {

				e.printStackTrace();
			} catch (IOException ioe) {

				ioe.printStackTrace();
				// throw new NullPointerException("Image not found");
			} catch (Exception expected) {
				expected.printStackTrace();
			}

			return encodeBase64(imageData);
		} else {
			return null;

		}
	}

}
