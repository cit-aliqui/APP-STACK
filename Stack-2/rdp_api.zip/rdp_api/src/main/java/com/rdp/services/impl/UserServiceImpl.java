package com.rdp.services.impl;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.UserDAO;
import com.rdp.domain.ResponseData;
import com.rdp.domain.User;
import com.rdp.exception.RDPException;
import com.rdp.security.utils.AuthTokenStore;
import com.rdp.security.utils.AuthorizationToken;
import com.rdp.security.utils.TokenGenerator;
import com.rdp.services.UserService;
import com.rdp.utils.ImageUtil;
import com.rdp.utils.RDPConfig;

/**
 * Service Implementation for managing User.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

    //private final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
    
    @Autowired
    private UserDAO userDAO;
        
    @Autowired
    private TokenGenerator tokenGenerator;
    
    @Autowired
    private AuthTokenStore authTokenStore;
  
    @Autowired
	private Environment environment;
    
    @Override
   	public User validateLogin(User user) throws RDPException {
       	String token = null;
   		User userinfo=null;
   		try {
   			if(user.getUsername() !=null && user.getPassword() !=null)
   			{
   				userinfo=userDAO.getuserbyusernamepass(user.getUsername().toUpperCase(), user.getPassword());
   			}
   			
   			if(userinfo !=null)
   			{
   				token = tokenGenerator.generateToken(user.getUsername());
   				userinfo.setToken(token);
   				int tokenExpTime = Integer.parseInt(RDPConfig.tokenExpTimeInSecs);
   				authTokenStore.storeToken(new AuthorizationToken(token, userinfo, tokenExpTime));
   			
   			
   			}
   		} catch (DataAccessException e) {
   			throw new RDPException(403, e.getMessage()); 
   		}catch (Exception e) {
   			throw new RDPException(403, e.getMessage());
   		}
   		return userinfo;
   	}


	@Override
	public Integer saveUser(User user,String resultPath, String realPath) throws RDPException {
		Integer result = null;
	
		try {
			result = userDAO.saveuser(user);
			user.setUserId(result);
			
	
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	

	@Override
	public User getUserById(Integer userId) throws RDPException {
		User users = null;
		
		try {
			users = userDAO.getuserById(userId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
					
		return users;
	}

	@Override
	public List<User> getusers() throws RDPException {
		List<User> usersList = null;
		try {
			usersList = userDAO.getusers();
		
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return usersList;
	}

	@Override
	public Integer deleteUser(Integer userId) throws RDPException {
		Integer result=null;
		try {
			result=userDAO.deleteuser(userId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	@Override
	public Integer updateUser(User user,String resultPath, String realPath) throws RDPException {
		Integer result = null;
		String filePathName = null;
		String fileName = null;

		try {
			result=userDAO.updateuser(user);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new RDPException(422, e.getMessage());
		}
		return result;
	}

	


	/**
	 * Validate the email check all theses **Check length of 10 or more digits.
	 * **Check for all digits or not.
	 * 
	 * @param phoneNumber
	 * @return
	 */
	private boolean validatePhoneNumber(String phoneNumber) {

		if (phoneNumber != null) {
			if (phoneNumber.length() >= 10) {
				/*
				 * Regular expression for digits one or more.
				 * 
				 */
				String regex = "\\+?\\d+";
				if (phoneNumber.matches(regex)) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}

	

	private boolean vaidateEmail(String emailId) {

		if (emailId != null) {
			if (emailId.contains("@")) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	public static String generateOtp(int size) {

		StringBuilder generatedToken = new StringBuilder();
		try {
			SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
			// Generate 20 integers 0..20
			for (int i = 0; i < size; i++) {
				generatedToken.append(number.nextInt(9));
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return generatedToken.toString();
	}



}
