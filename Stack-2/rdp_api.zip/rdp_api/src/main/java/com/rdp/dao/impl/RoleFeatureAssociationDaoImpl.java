package com.rdp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.RoleFeatureAssociationDao;
import com.rdp.domain.RoleFeaturAssociation;
import com.rdp.exception.RDPException;

@Repository
@Transactional
public class RoleFeatureAssociationDaoImpl implements RoleFeatureAssociationDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private Environment environment;

	@Override
	public Integer saveRoleFeatureAssociation(RoleFeaturAssociation roleFeatureAssociation) throws RDPException {
		String query = null;
		Object[] params = null;
		Integer result = 0;

		query = environment.getProperty("INSERT_INTO_ROLE_FEATURE_ASSOCIATION");
		params = new Object[] { roleFeatureAssociation.getRoleId(), roleFeatureAssociation.getFeatureId() };
		result = jdbcTemplate.update(query, params);

		return result;
	}

	@Override
	public Integer updateRoleFeatureAssociation(RoleFeaturAssociation roleFeatureAssociation)
			throws RDPException {
		String query = null;
		Object[] params = null;
		Integer result = 0;

		query = environment.getProperty("UPDATE_ROLE_FEATURE_ASSOCIATION");
		params = new Object[] { roleFeatureAssociation.getRoleFeatureAssociateId(), roleFeatureAssociation.getRoleId(),
				roleFeatureAssociation.getFeatureId() };
		result = jdbcTemplate.update(query, params);

		return result;
	}

	@Override
	public Integer deleteRoleFeatureAssocitation(Integer roleFeatureAssociationId) throws RDPException {
		String query = null;
		Object[] params = null;
		Integer result = 0;

		query = environment.getProperty("DELETE_ROLE_FEATURE_ASSOCIATION");
		params = new Object[] { roleFeatureAssociationId };
		result = jdbcTemplate.update(query, params);

		return result;
	}

	@Override
	public List<RoleFeaturAssociation> getRoleFeatureAssociationById(Integer roleId) throws RDPException {
		String query = null;
		List<RoleFeaturAssociation> roleFeatureAssociation = null;
		Object[] params = null;

		params = new Object[] { roleId };
		query = environment.getProperty("SELECT_ROLE_FEATURE_ASSOCIATION_BY_ID");

		roleFeatureAssociation = jdbcTemplate.query(query, params, this::matchRows);
		return roleFeatureAssociation;
	}

	@Override
	public List<RoleFeaturAssociation> getRoleFeatureAssociation() throws RDPException {
		String query = null;
		List<RoleFeaturAssociation> roleFeatureAssociationList = null;

		query = environment.getProperty("SELECT_ROLE_FEATURE_ASSOCIATION");

		roleFeatureAssociationList = jdbcTemplate.query(query, this::matchRows);
		return roleFeatureAssociationList;

	}

	@Override
	public int[] batchUpdate(List<Object[]> roleFeatureAssociationIds) throws RDPException {
		String query = null;
		int[] params = null;

		// params=new
		// Object[]{workItemToolsAssociation.getWorkItemId(),workItemToolsAssociation.getToolId()};
		query = environment.getProperty("INSERT_INTO_ROLE_FEATURE_ASSOCIATION");
		params = jdbcTemplate.batchUpdate(query, roleFeatureAssociationIds);

		return params;

	}

	private RoleFeaturAssociation matchRows(ResultSet rs, int rowNumber) throws SQLException {
		RoleFeaturAssociation r = new RoleFeaturAssociation();
		r.setRoleFeatureAssociateId(rs.getInt("RF_Association_Id"));
		r.setRoleId(rs.getInt("Role_Id"));
		r.setFeatureId(rs.getInt("Feature_Id"));
		r.setFeatureName(rs.getString("Feature_Name"));
		r.setSubFeatureId(rs.getInt("Sub_Feature_Id"));
		r.setSubFeatureName(rs.getString("Sub_Feature_Name"));
		

		return r;
	}

}
