package com.rdp.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rdp.dao.RoleDao;
import com.rdp.dao.RoleFeatureAssociationDao;
import com.rdp.domain.Feature;
import com.rdp.domain.Role;
import com.rdp.domain.SubFeatures;
import com.rdp.exception.RDPException;

@Repository
@Transactional
public class RoleDaoImpl implements RoleDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private Environment environment;

	@Autowired
	private RoleFeatureAssociationDao roleFeatureAssociation;

	@Override
	public Integer saveRole(Role role) throws RDPException {
		Integer result = 0;

		final PreparedStatementCreator preparedStatementCreator = (connection) -> {
			final PreparedStatement ps = connection.prepareStatement(environment.getProperty("INSERT_ROLE"),
					Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, role.getRoleName());
			ps.setString(2, role.getDescription());
			return ps;
		};

		// The newly generated key will be saved in this object
		final KeyHolder holder = new GeneratedKeyHolder();
		result = jdbcTemplate.update(preparedStatementCreator, holder);

		result = holder.getKey().intValue();

		return result;

	}

	@Override
	public Integer updateRole(Role role) throws RDPException {
		String query = null;
		Object[] params = null;
		Integer result = 0;

		query = environment.getProperty("UPDATE_ROLE");
		params = new Object[] { role.getRoleName(), role.getDescription(), role.getRoleId() };
		result = jdbcTemplate.update(query, params);

		return result;
	}

	@Override
	public Integer deleteRole(Integer roleId) throws RDPException {
		String query = null;
		Object[] params = null;
		Integer result = 0;

		query = environment.getProperty("DELETE_ROLE");
		params = new Object[] { roleId };
		result = jdbcTemplate.update(query, params);

		return result;
	}

	@Override
	public Role getRoleById(Integer roleId) throws RDPException {
		String query = null;
		Role role = null;
		Object[] params = null;

		params = new Object[] { roleId };
		query = environment.getProperty("SELECT_ROLE_BY_ID");

		role = jdbcTemplate.query(query, params, this::matchRows).get(0);
		return role;
	}

	@Override
	public List<Role> getRoles() throws RDPException {
		String query = null;
		List<Role> roleList = null;

		query = environment.getProperty("SELECT_ROLE");

		roleList = jdbcTemplate.query(query, this::matchRows);
		return roleList;

	}

	private Role matchRows(ResultSet rs, int rowNumber) throws SQLException {
		Role r = new Role();
		r.setRoleId(rs.getInt("Role_Id"));
		r.setRoleName(rs.getString("Role_Name"));
		r.setDescription(rs.getString("Description"));

		return r;
	}

	@Override
	public List<Feature> getFeaturesbyroleId(Integer roleId) throws RDPException {
		String query=null;
		List<Feature>  featureList=null;
Object[] params=null;
		
		
		params=new Object[]{roleId};
		
		
		
		query=environment.getProperty("SELECT_FEATURES_BY_ROLEID");
		
		featureList=jdbcTemplate.query(query,(rs,rowNum)->{
			Feature f=new Feature();
			f.setFeatureId(rs.getInt("Feature_Id"));
			f.setFeatureName(rs.getString("Feature_Name"));
			f.setFeatureDesc(rs.getString("Description"));		
			
			return f;
		},params);
	return featureList;	
	}

	@Override
	public List<SubFeatures> getSubFeaturesbyfeatureId(Integer featureId,Integer roleId) throws RDPException {
		String query=null;
		List<SubFeatures>  subfeatureList=null;
Object[] params=null;
		
		
		params=new Object[]{featureId,roleId};
		
		
		query=environment.getProperty("SELECT_SUBFEATURES_BY_FEATUREID");
		
		subfeatureList=jdbcTemplate.query(query,(rs,rowNum)->{
			SubFeatures sf=new SubFeatures();
			sf.setSubFeatureId(rs.getInt("Sub_Feature_Id"));
			sf.setSubFeatureName(rs.getString("Sub_Feature_Name"));
			sf.setSubfeaturedescription(rs.getString("Sub_Feature_Desc"));
			sf.setSubFeatureURL(rs.getString("Sub_Feature_URL"));
			sf.setFeatureId(rs.getInt("Feature_Id"));
			
			return sf;
		},params);
	return subfeatureList;	
	}

}
