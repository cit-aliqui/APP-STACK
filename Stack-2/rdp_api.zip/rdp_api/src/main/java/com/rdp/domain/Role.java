package com.rdp.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Role implements Serializable {

	private static final long serialVersionUID = 6781606468617911321L;
	private Integer roleId;
	private String roleName;
	private String description;
	private List<Feature> featureList;

	private ErrorResp erroResponse;

	public ErrorResp getErroResponse() {
		return erroResponse;
	}

	public void setErroResponse(ErrorResp erroResponse) {
		this.erroResponse = erroResponse;
	}

	public List<Feature> getFeatureList() {
		return featureList;
	}

	public void setFeatureList(List<Feature> featureList) {
		this.featureList = featureList;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
