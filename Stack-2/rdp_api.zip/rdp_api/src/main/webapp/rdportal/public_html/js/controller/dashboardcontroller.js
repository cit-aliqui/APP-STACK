'use strict';

angular.module('myApp.dashboardcontroller', [])
        .controller('DashboardCtrl', ['$timeout', '$scope', '$rootScope', '$window', '$location', '$http', '$sessionStorage','$routeParams','$localStorage', 'dashboardService', function ($timeout, $scope, $rootScope, $window, $location, $http, $sessionStorage,$routeParams,$localStorage, rduService, orgService, clusterService, motherplantService, dashboardService) {
        	$scope.slide = '';
            $scope.loginData = {};   
            $scope.showdashbaord=false;
            console.log("ROOTSCOPE LOGIN "+$rootScope.isLogin); 
            if($rootScope.isLogin==true) {
               $sessionStorage.Login =true;  
             
              if($localStorage.features.length>0)
            	  {
            	  for(var i=0;i<$localStorage.features.length;i++)
            		  {
            		  if($localStorage.features[i].featureName.toUpperCase()=='DASHBOARD')
            			  {
            			   $scope.showdashbaord=true;
            			  }
            		  }
            	  }
            }                
            if($sessionStorage.Login) {
               $rootScope.isLogin =true;  
            } else {
               $rootScope.isLogin =false;
            }
       
            }]);


