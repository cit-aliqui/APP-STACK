'use strict';

angular.module('myApp.resetPasswordController', [])
        .controller('resetPasswordController', ['$scope','$sessionStorage','$location','$rootScope', '$http', '$interval', '$q' ,'resetPasswordService','FlashService',function ($scope,$rootScope, $location,$http, $interval,$sessionStorage, $q,resetPasswordService,FlashService) {
 var phoneno = /^\d{10}$/;  
 var otpformat = /^\d{6}$/; 
 var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
  $scope.otpstatus=false;
  $scope.password=false;
  $scope.mailpassword=false;
  $scope.updationsuccess=false;
  $scope.inemail=true;
  $scope.otpalerttype="alert alert-success";
  $scope.emailalerttype="alert alert-success";
  $scope.inotp=true;
  $scope.disablebutton=false;
  $rootScope.otpsenttime=0;
  $sessionStorage.home="";
  $scope.mailsenttime=0;
  var str="";
  $scope.number="";
  $scope.otp="";
  $scope.password1="";
  $scope.password2="";
 var firstpass="";
 var secondpass="";
  var res=[];
  var number="";
  var email="";
  var otp="";
  $scope.email="";
 /* var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}*/
  $rootScope.isTrascError = false;
  $scope.continuesave = true;	
  onload();
  function onload(){

	//  $rootScope.isResetpage=true;

	  var link=window.location.href;
	  res = link.split("?");
	  if(res.length>1)
		  {
	
	  str=window.atob(res[1]);

	  var n = str.indexOf("(");
	    var d= str.indexOf(")");
	    
	    var nn= str.indexOf("(",str.indexOf("(")+1);
	    var dd=str.indexOf(")",str.indexOf(")")+1);
	    var substr=str.substr(n+1,d-n-1);
	    var substr2=str.substr(nn+1,dd-nn-1);
	 
	   $scope.mailsenttime=substr2;
	    var d = new Date(parseInt(substr2));
	  
	    var diffinmilisec=new Date(new Date()-d);
	    var diffinhours=parseInt(diffinmilisec / (1000*60*60)) % 24;
	 
	    
	 
	 if(diffinhours==0)
		 {
	$scope.email=substr;
	$scope.mailpassword=true;
	dothis();
		 }
	 else
	 {

$scope.successTextAlertEmail="Activation link got expired,Please reset password again";
FlashService.Error("Activation link got expired,Please reset password again");
$scope.emailalerttype="alert alert-danger";



$scope.bgcolor="red";

	 }
		  }
	  
  }
  $scope.sendmobilenumber=function()
             {

	  $scope.disablebutton=true;
 number= document.getElementById("mobile").value;
$scope.number=number;

	     if (number.length>10 || number.length<10  || number=="") {
	  
            $rootScope.isTrascError = true;
            FlashService.Error("Please Enter correct Mobile Number");
            $scope.successTextAlertOTP="Please Enter correct Mobile Number";
            $scope.otpalerttype="alert alert-danger";
            $scope.bgcolor="red";
            $scope.continuesave = false;
            $scope.disablebutton=false;
        }
	     else if(number.length ==10)
         	 {
         
          	 if(number.match(phoneno))  
          		        {  
          		  $rootScope.isTrascError = false;
          		 $scope.continuesave = true;
          		        }  
          		      else  
          		        {  
          		    	  $rootScope.isTrascError = true;
                            FlashService.Error("Please Enter correct Mobile Number");
                            $scope.successTextAlertOTP="Please Enter correct Mobile Number";
                            $scope.otpalerttype="alert alert-danger";
                            $scope.bgcolor="red";
                            $scope.continuesave = false;
                            $scope.disablebutton=false;
          		        }  
         	 }
	     if ($scope.continuesave) {
	    	 var headers = {
	      			    'phoneNumber':number,
	      			 //  'Auth_Token':$rootScope.globals.userDTO.token
	      			  }

	      	  var config={
	      			  headers:headers
	      	  }
	    	 resetPasswordService
             .sendMobilenumber(config)
             .then(
                     function (result) {
                         if (result.httpStatus == 200) {
                             $scope.otpstatus=true;
                           
                             $scope.successTextAlertOTP = result.data.message;
                             FlashService.Success(result.data.message);
                             $scope.bgcolor="green";
                             $scope.otpalerttype="alert alert-success";
                             $scope.showSuccessAlert = true;
                             $rootScope.otpsenttime=result.data.time;
                             $scope.disablebutton=false;
                        
                         
                         } else {
                             $rootScope.isTrascError = true;
                         
                             FlashService.Error(result.data.message);
                             $scope.successTextAlertOTP=result.data.message;
                             $scope.otpalerttype="alert alert-danger";
                             $scope.bgcolor="red";
                             $scope.continuesave = false;
                             $scope.disablebutton=false;
                         }
                         $timeout(function () {
                             $scope.showSuccessAlert = false;
                         }, 5000);
                     });
	     }

}
        	 $scope.validateotp=function()
             {
        		  $scope.disablebutton=true;
        		 var d = new Date(parseInt( $rootScope.otpsenttime));
     		 
     		    var diffinmilisec=new Date(new Date()-d);
     		    var diffinhours=parseInt(diffinmilisec / (1000*60*60)) % 24;
     		 if(diffinhours>0)
     			 {
     			 $scope.number="";
                  $scope.successTextAlertOTP = "OTP as expired please reset password again";
                  FlashService.Error("OTP as expired please reset password again");
                  $scope.bgcolor="red";
                  $scope.showSuccessAlert = true;
                  $scope.otpalerttype="alert alert-danger";
                  $scope.password1="";
                  $scope.password2="";
                  $scope.otpstatus=false;
                  $scope.password=false;
                  $scope.disablebutton=false;
     			 }
     		 else
     			 {
     			
        		
        		  var user={};
        		 
	
	otp= document.getElementById("otp").value;
	$scope.otp=otp;
	 user.otp=otp;
	
	 user.primaryMobileNo=$scope.number;
	
	 
		     if (otp.length>6 || otp.length<6 && otp!="") {
	            $rootScope.isTrascError = true;
	            FlashService.Error("Please provide valid OTP");
	            $scope.bgcolor="red";
	            $scope.successTextAlertOTP="Please provide valid OTP";
	            $scope.otpalerttype="alert alert-danger";
	            
	            $scope.continuesave = false;
	            $scope.disablebutton=false;
	        }
		     else if(otp.length ==6)
	         	 {
	         
	          	 if(otp.match(otpformat))  
	          		        {  
	          		  $rootScope.isTrascError = false;
	          		 $scope.continuesave = true;
	          		        }  
	          		      else  
	          		        {  
	          		    	
	          		    	  $rootScope.isTrascError = true;
	                            FlashService.Error("Please provide valid OTP");
	                            $scope.bgcolor="red";
	                            $scope.successTextAlertOTP="Please provide valid OTP";
	                            $scope.otpalerttype="alert alert-danger";
	                            $scope.continuesave = false;
	                            $scope.disablebutton=false;
	          		        }  
	         	 }
		    
		     if ($scope.continuesave) {
		  

		      
		      	  
		    	 resetPasswordService
	             .validateotp(user)
	             .then(
	                     function (result) {
	                         if (result.httpStatus == 200) {
	                        	 $scope.otpstatus=false;
	                        	 $scope.password=true;
	                             $scope.successTextAlertOTP = result.data.message;
	                             $scope.bgcolor="green";
	                             $scope.otpalerttype="alert alert-success";
	                             FlashService.Success(result.data.message);
	                             $scope.showSuccessAlert = true;
	                             $scope.disablebutton=false;
	                         } else {
	                             $rootScope.isTrascError = true;
	                             $scope.otpstatus=true;
	                        	 $scope.password=false;
	                             FlashService.Error(result.data.message);
	                             $scope.bgcolor="red";
	                             $scope.otpalerttype="alert alert-danger";
	                             $scope.successTextAlertOTP = result.data.message;
	                             $scope.continuesave = false;
	                             $scope.disablebutton=false;
	                         }
	                         $timeout(function () {
	                             $scope.showSuccessAlert = false;
	                         }, 5000);
	                     });
		     }
     			 }

}
        	 $scope.sendmail=function()
        	 {
        		
        		 $scope.disablebutton=true;	
        		 email= document.getElementById("email").value;
        		$scope.email=email;
        	     if(email !="" )
            	 {
            	
            	 if(email.match(mailformat))  
            	 {  
            		 $rootScope.isTrascError = false;
              		 $scope.continuesave = true;
              		 
            	 }  
            	 else  
            	 {  
            		  $rootScope.isTrascError = true;
                      FlashService.Error("Please Enter correct  Email Id");
                      $scope.successTextAlertEmail = "Please Enter correct  Email Id";
                      $scope.emailalerttype="alert alert-danger";
                      $scope.bgcolor="red";
                      $scope.continuesave = false;
                      $scope.disablebutton=false;
            	 }  
            	 }
        	     else
        	    	 {
        	    	  $rootScope.isTrascError = true;
                      FlashService.Error("Email Id should not be Empty");
                      $scope.successTextAlertEmail = "Email Id should not be Empty";
                      $scope.bgcolor="red";
                      $scope.emailalerttype="alert alert-danger";

                      $scope.continuesave = false;
                      $scope.disablebutton=false;
        	    	 }
        			     if ($scope.continuesave) {
        			    	 var headers = {
        			      			    'emailId':email,
        			      			  // 'Auth_Token':$rootScope.globals.userDTO.token
        			      			  }

        			      	  var config={
        			      			  headers:headers
        			      	  }
        			    	 resetPasswordService
        		             .sendMail(config)
        		             .then(
        		                     function (result) {
        		                         if (result.httpStatus == 200) {
        		                            //$scope.password=true;
        		                        	 $scope.email="";
        		                             $scope.successTextAlertEmail = result.data.message;
        		                             $scope.showSuccessAlert = true;
        		                             $scope.bgcolor="green";
        		                             $scope.emailalerttype="alert alert-success";
        		                             FlashService.Success(result.data.message);
        		                             $scope.updationsuccess=false;
        		                             $scope.disablebutton=false;

        		                         } else {
        		                             $rootScope.isTrascError = true;
        		                        	 $scope.email="";
        		                             $scope.bgcolor="red";
        		                             $scope.emailalerttype="alert alert-danger";
        		                             $scope.successTextAlertEmail = result.data.message;
        		                             FlashService.Error(result.data.message);
        		                             $scope.continuesave = false;
        		                             $scope.updationsuccess=false;
        		                             $scope.disablebutton=false;
        		                         }
        		                         $timeout(function () {
        		                             $scope.showSuccessAlert = false;
        		                         }, 5000);
        		                     });
        			     }
        	 }
        	 $scope.resetbymobile=function()
        	 {
        		
        		 $scope.disablebutton=true;
        		 var d = new Date(parseInt( $rootScope.otpsenttime));
        		  
        		    var diffinmilisec=new Date(new Date()-d);
        		    var diffinhours=parseInt(diffinmilisec / (1000*60*60)) % 24;
        		 if(diffinhours>0)
        			 {
        			 $scope.number="";
                     $scope.successTextAlertOTP = "OTP as expired please reset password again";
                     FlashService.Error("OTP as expired please reset password again");
                     $scope.otpalerttype="alert alert-danger";
                     $scope.bgcolor="red";
                     $scope.showSuccessAlert = true;
                     $scope.updationsuccess=true;
                     $scope.password1="";
                     $scope.password2="";
                     $scope.otpstatus=false;
                     $scope.password=false;
                     $scope.disablebutton=false;
        			 }
        		 else
        			 {
        			
        	  firstpass = document.getElementById("firstpassword").value;
        	  secondpass= document.getElementById("secondpassword").value;
        	  
        	var user={};
        	user.primaryMobileNo=$scope.number;
        	user.password=window.btoa(firstpass);
        	     if(firstpass !="" && secondpass!="")
            	 {
            	
            	 if(firstpass==secondpass)  
            	 {  
            		 $rootScope.isTrascError = false;
              		 $scope.continuesave = true;
            	 } 
            	 else
            		 {
            		 $rootScope.isTrascError = true;
                     FlashService.Error("Both password should be equal");
                     $scope.successTextAlertOTP = "Both password should be equal";
                     $scope.bgcolor="red";
                     $scope.otpalerttype="alert alert-danger";
                     $scope.continuesave = false;
                     $scope.disablebutton=false;
            		 }
            	 }
            	 else  
            	 {  
            		  $rootScope.isTrascError = true;
                      FlashService.Error("Password fileds should not be empty");
                      $scope.successTextAlertOTP = "Password fileds should not be empty";
                      $scope.bgcolor="red";
                      $scope.otpalerttype="alert alert-danger";
                      $scope.continuesave = false;
                      $scope.disablebutton=false;
            	 }  
            	 
        			     if ($scope.continuesave) {
        			    
        			     
        			    	 resetPasswordService
        		             .resetpasswordbyotp(user)
        		             .then(
        		                     function (result) {
        		                         if (result.httpStatus == 200) {
        		                            //$scope.password=true;
        		                        	 $scope.number="";
        		                             $scope.successTextAlertOTP = result.data.message;
        		                             FlashService.Success(result.data.message);
        		                             $scope.bgcolor="green";
        		                             $scope.otpalerttype="alert alert-success";
        		                             $scope.showSuccessAlert = true;
        		                             $scope.updationsuccess=true;
        		                             $scope.password1="";
        		                             $scope.password2="";
        		                             $scope.otpstatus=false;
        		                             $scope.password=false;
        		                             $sessionStorage.afterrestpass=true;
        		                             $sessionStorage.resetpage=false;
        		                             $scope.disablebutton=false;
        		                             alert(  $scope.successTextAlertOTP);
        		                             window.open($rootScope.home,"_self");

        		                         } else {
        		                             $rootScope.isTrascError = true;
        		                        	 $scope.email="";
        		                        	  $scope.bgcolor="red";
        		                        	  $scope.otpalerttype="alert alert-danger";
        		                             $scope.successTextAlertOTP = result.data.message;
        		                             FlashService.Error(result.data.message);
        		                             $scope.continuesave = false;
        		                             $scope.disablebutton=false;
        		                         }
        		                         $timeout(function () {
        		                             $scope.showSuccessAlert = false;
        		                         }, 5000);
        		                     });
        			     }
        			 }
        	 }
        	 $scope.resetbyemail=function()
        	 {
        		 $scope.disablebutton=true;
        		  var d = new Date(parseInt($scope.mailsenttime));
        		 
        		  
        		    var diffinmilisec=new Date(new Date()-d);
        		    var diffinhours=parseInt(diffinmilisec / (1000*60*60)) % 24;
        		 if(diffinhours>0)
        			 {
        			
        			$scope.successTextAlertEmail="Activation link got expired,Please reset password again";
        			  FlashService.Error("Activation link got expired,Please reset password again");
                      $scope.emailalerttype="alert alert-danger";
        			  $scope.bgcolor="red";
        			 $scope.email="";
                     $scope.firstpassword="";
                     $scope.secondpassword="";
                     $scope.mailpassword=false;
                     $scope.mail="";
                     $scope.disablebutton=false;
        			 }
        		 {
        		
        			
        	  firstpass = document.getElementById("firstpassword").value;
        	  secondpass= document.getElementById("secondpassword").value;
        	  
        	 var user={};
        	user.primaryEmail=$scope.email;
        	user.password=window.btoa(firstpass);
        	     if(firstpass !="" && secondpass!="")
            	 {
            	
            	 if(firstpass==secondpass)  
            	 {  
            		 $rootScope.isTrascError = false;
              		 $scope.continuesave = true;
            	 } 
            	 else
            		 {
            		 $rootScope.isTrascError = true;
                     FlashService.Error("Both password should be equal");
                     $scope.successTextAlertEmail = "Both password should be equal";
                     $scope.bgcolor="red";
                     $scope.emailalerttype="alert alert-danger";

                     $scope.continuesave = false;
                     $scope.disablebutton=false;
            		 }
            	 }
            	 else  
            	 {  
            		  $rootScope.isTrascError = true;
                      FlashService.Error("Password fileds should not be empty");
                      $scope.successTextAlertEmail = "Password fileds should not be empty";
                      $scope.bgcolor="red";
                      $scope.emailalerttype="alert alert-danger";
                      $scope.continuesave = false;
                      $scope.disablebutton=false;
            	 }  
            	 
        			     if ($scope.continuesave) {
        			    
        			      
        			    	 resetPasswordService
        		             .resetpasswordbyotp(user)
        		             .then(
        		                     function (result) {
        		                         if (result.httpStatus == 200) {
        		                            //$scope.password=true;
        		                        	 $scope.email="";
        		                             $scope.successTextAlertEmail = result.data.message;
        		                             $scope.firstpassword="";
        		                             $scope.secondpassword="";
        		                             $scope.mailpassword=false;
        		                             $scope.mail="";
        		                             $location.path('/login');
        		                             $scope.bgcolor="green";
        		                             $scope.emailalerttype="alert alert-success";
        		                             $scope.updationsuccess=true;
        		                            $sessionStorage.afterrestpass=true;
        		                             $sessionStorage.resetpage=false;
        		                             FlashService.Success(result.data.message);
        		                             $scope.showSuccessAlert = true;
        		                             $scope.disablebutton=false;
        		                           alert( $scope.successTextAlertEmail);
        		                             window.open($rootScope.home,"_self");
        		                         } else {
        		                             $rootScope.isTrascError = true;
        		                             $scope.bgcolor="red";
        		                             $scope.emailalerttype="alert alert-danger";
        		                             $scope.successTextAlertEmail = result.data.message;
        		                             FlashService.Error(result.data.message);
        		                             $scope.continuesave = false;
        		                             $scope.disablebutton=false;
        		                         }
        		                         $timeout(function () {
        		                             $scope.showSuccessAlert = false;
        		                         }, 5000);
        		                     });
        			     }
        		 }
        	 }
        	 function dothis() {
    			
    				$("#register-form").delay(100).fadeIn(100);
    			
    		 		$("#login-form").fadeOut(100);
    		 	
    				$('#login-form-link').removeClass('active');
    				
    				$("#register-form-link").addClass('active');
    			
    				//event.preventDefault();
    				
    			}
        	 function fadeoffalert() {
        		 setTimeout(function(){
        			    document.getElementById("result").innerHTML="";
        			    }, 5000);
        	 }
        	 
        	    $scope.signin = function()
                {
                
                	

			
       
                	 $rootScope.isLogin=true;
                
                	 $rootScope.isResetpage=false;
                	
							$location.path('/login');
							
						
							$sessionStorage.resetpage=false;
							
                             window.open($rootScope.home,"_self");

                }
        	    $scope.hidemessageinotp = function()
        	    {
        	    
        	    	$scope.inotp=false;
        	    	$scope.inemail=true;
        	    	
        	    	
        	    }
        	    $scope.hidemessageinemail = function()
        	    {
        	    
        	    	$scope.inemail=false;
        	    	$scope.inotp=true;
        	    	
        	    }
        	   
            }]);
