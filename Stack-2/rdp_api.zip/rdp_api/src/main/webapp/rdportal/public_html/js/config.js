angular.module('myApp.config', []).constant('configData',{
    "url":'http://localhost:8080/rdp-api/'
});