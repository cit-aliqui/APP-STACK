'use strict';

angular.module('myApp.userController', [])
        .controller('userController', ['$scope','$rootScope', '$timeout','$http', '$interval', '$q' ,'userService','FlashService',function ($scope,$rootScope,$timeout, $http, $interval, $q,userService,FlashService) {
$scope.userList=[];
  $scope.userId=null;
  $scope.functionality="";
  $scope.myJsonString=[];
  $scope.business={};
  $scope.workPackagemultiobj={};
  $scope.workPackagemultiselect=[];
  $scope.workPackageList=[];
  $scope.businessselect=[];
  $scope.example14model = [];
  $scope.list=[];
  $scope.example6model=[];
 // $scope.example6data = [ { id: 1, label: 'David' }, { id: 2, label: 'Jhon' }, { id: 3, label: 'Danny' } ];
  $scope.example6settings = {
		 /* scrollableHeight: '300px',
	      scrollable: true,
	      enableSearch: true  */
  };
  $scope.customFilter = '';
 
  
  $scope.loclist =[];

  $scope.example2settings = {
      displayProp: 'id'
  };
  var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}
var phoneno = /^\d{10}$/;  
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
  $scope.maxDate = new Date();
  $scope.statuses = [{
      "statusId" : "M" ,
      "statusName" : "Male"
    },
    {
      "statusId" : "F" ,
      "statusName" : "Female"
    }];
$scope.statusId = "M";
$scope.usertypes = [{
    "typeId" : "Internal" ,
    "typeName" : "Internal"
  },
  {
    "typeId" : "External" ,
    "typeName" : "External"
  }];
$scope.userType = "Internal";
$scope.inputType = 'password';

// Hide & show password function
$scope.hideShowPassword = function(){
  if ($scope.inputType == 'password')
    $scope.inputType = 'text';
  else
    $scope.inputType = 'password';
};

  this.myDate = new Date();

  this.isOpen = false;
	$scope.userImage = "assets/global/img/profile.jpg";
  var fakeI18n = function( title ){
	    var deferred = $q.defer();
	    $interval( function() {
	      deferred.resolve( 'col: ' + title );
	    }, 1000, 1);
	    return deferred.promise;
	  };
	  $scope.gridOptions = {
	  };

            $scope.gridOptions = {
              paginationPageSizes: [25, 50, 75],
              paginationPageSize: 25,
              exporterMenuCsv: true,
              enableGridMenu: true,
              enableFiltering: true,
              gridMenuTitleFilter: fakeI18n,
              columnDefs: [
                { name: 'username', displayName:"User Name" },
                {name:'roleName',displayName:"Role Name" },
                { name: 'fullName', displayName:"Full Name" },
                {name:'dob',displayName:"Date of Birth" },
                { name: 'userType', displayName:"User Type" },
                {name:'gender',displayName:"Gender" },
                { name: 'primaryEmail', displayName:"Primary Email Id" },
                {name:'primaryMobileNo',displayName:"Primary Mobile Number" },
                { name: 'country', displayName:"Country" },
                {name:'state',displayName:"State" },
                {name:'userId',displayName:"Action",cellTemplate: '<div  class="ui-grid-cell-contents" >  <div class="col-sm-12 lookup-action"> \
                     &nbsp; <i class="fa fa-pencil-square-o" ng-click="grid.appScope.editUser(COL_FIELD)" style="cursor:pointer" ></i> \
                     &nbsp; <i class="fa fa-eye" ng-click="grid.appScope.viewUser(COL_FIELD)"  style="cursor:pointer"></i> \
                 </div></div> ',enableFiltering: false,width:100}
              ],

              onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;

                // interval of zero just to allow the directive to have initialized


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                  $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
              }
            };

          /*  $http.get('http://ui-grid.info/data/100.json')
              .success(function(data) {
                $scope.gridOptions.data = data;
              });*/
      loadAll();
      function loadAll(){
    	 
      $scope.workPackagemultiselect=[];
      $scope.contractorsmultiselect=[];
      $scope.consultancymultiselect=[];
      $scope.list=[];
     
       
        userService.getAllUsers(config).then(function (data) {

             $scope.userList= data.data.objects;

             for(var i=0;i<$scope.userList.length;i++)
             {

                  $scope.userList[i].action="";

             }
               $scope.gridOptions.data =$scope.userList;
          });
          userService.getAllRoles(config).then(function (data) {

               $scope.roleList= data.data.objects;
            });
            userService.getAllOrganizations(config).then(function (data) {
                 $scope.OrganizationList= data.data.objects;

              });
              userService.getAllBuisnessUnits(config).then(function (data) {
                   $scope.BusinessList= data.data.objects;


              });
              userService.getAllProjecttypes(config).then(function (data) {
                     $scope.projectTypeList= data.data.objects;

              });
              userService.getAllProjectSites(config).then(function (data) {
                       $scope.projectSiteList= data.data.objects;

              });
              userService.getAllProjectPhase(config).then(function (data) {
                         $scope.projectPhaseList= data.data.objects;

              });
              userService.getAllBuildingFloor(config).then(function (data) {
                           $scope.BuildingFloorList= data.data.objects;

              });
              userService.getAllBuildingType(config).then(function (data) {
                           $scope.BuildingTypeList= data.data.objects;

              });
              userService.getAllBuildingUnits(config).then(function (data) {
                            $scope.buildingUnitList= data.data.objects;

              });
              userService.getAllBuildingSubUnits(config).then(function (data) {
                               $scope.buildingSubUnitList= data.data.objects;

              });
              userService.getAllWorkPackages(config).then(function (data) {
                               $scope.workPackageList= data.data.objects;
                              if( $scope.workPackageList.length>0)
                            	   {
                            	   for(var i=0;i<$scope.workPackageList.length;i++)
                            		   {
                            		   $scope.obj={};
                                       
                                       $scope.obj.id=$scope.workPackageList[i].workPackageId;
                                       $scope.obj.label=$scope.workPackageList[i].name;
                                       $scope.list.push($scope.obj);
                            		   }
                            	   }
                               
                             
                          
                           //   $scope.example6data = [ { id: 1, label: 'David' }, { id: 2, label: 'Jhon' }, { id: 3, label: 'Danny' } ];
                               $scope.example6data =  $scope.list;
                              

                             //  alert( $scope.workPackageList.length);
                              // workpackagemultiselect();
                              

              });
            
              userService.getAllContractors(config).then(function (data) {
                               $scope.contractorList= data.data.objects;

              });
              userService.getAllConsultancy(config).then(function (data) {
                               $scope.consultancyList= data.data.objects;

              });
        console.log("----------"+$scope.userList);
      }

      $scope.createUser = function () {
    	  $scope.functionality="Save";
        $scope.headername = "Create User";
        $scope.profileImage="";
        $scope.username="";
        $scope.password="";
        $scope.roleId ="";
        $scope.fullName="";
        $scope.dob="";
        $scope.userType="";
        $scope.gender="";
        $scope.identityNumber="";
        $scope.primaryEmail="";
        $scope.alternateEmail="";
        $scope.primaryMobileNo="";
        $scope.alternateMobileNo="";
        $scope.country="";
        $scope.state="";
        $scope.city="";
        $scope.zipcode="";
        $scope.address="";
        $scope.orgId=null;
        $scope.businessunitId=null;
        $scope.projecttypeId=null;
        $scope.projectsiteId=null;
        $scope.projectphaseId=null;
        $scope.projectsiteId=null;
        $scope.projectphaseId=null;
        $scope.buildingtypeId=null;
        $scope.buildingfloorId=null;
        $scope.buildingunitId=null;
        $scope.buildingsubunitunitId=null;
        $scope.consultancyId=null;
        $scope.workpackageId=null;
        $scope.contractorId=null;
        $scope.example6model=[];


      //  $scope.category={};
      $scope.userId=null;

        $rootScope.isTrascError = false;
        $scope.isView = false;
        $('div').removeClass('has-error edited').removeClass('has-error');
        $('input').removeClass('form-control edited').addClass('form-control');
        $('textarea').removeClass('form-control edited').addClass('form-control');
        $('select').removeClass('form-control edited').addClass('form-control');
        $('#user-model').modal('show');
      }
      $scope.editUser=function(value)
      	{
    	  $scope.functionality="Update";
    	  $scope.isView = false;
        	$scope.headername = "Edit User Profile";
          $scope.profileImage="";
          $scope.username="";
          $scope.password="";
          $scope.roleId ="";
          $scope.fullName="";
          $scope.dob="";
          $scope.userType="";
          $scope.gender="";
          $scope.identityNumber="";
          $scope.primaryEmail="";
          $scope.alternateEmail="";
          $scope.primaryMobileNo="";
          $scope.alternateMobileNo="";
          $scope.country="";
          $scope.state="";
          $scope.city="";
          $scope.zipcode="";
          $scope.address="";
          $scope.orgId=null;
          $scope.businessunitId=null;
          $scope.projecttypeId=null;
          $scope.projectsiteId=null;
          $scope.projectphaseId=null;
          $scope.projectsiteId=null;
          $scope.projectphaseId=null;
          $scope.buildingtypeId=null;
          $scope.buildingfloorId=null;
          $scope.buildingunitId=null;
          $scope.buildingsubunitunitId=null;
          $scope.consultancyId=null;
          $scope.workpackageId=null;
          $scope.contractorId=null;
          $scope.userId=value;
          $scope.example6model=[];

          for(var i=0;i<$scope.userList.length;i++)
          {
              if ($scope.userList[i].userId==value)
               {

                $scope.userId=$scope.userList[i].userId;
                 $scope.username=$scope.userList[i].username;
                 $scope.password=window.atob($scope.userList[i].password);
                 $scope.roleId =$scope.userList[i].roleId;
                 $scope.fullName=$scope.userList[i].fullName;
                 $scope.dob=$scope.userList[i].dob;
                 $scope.userType=$scope.userList[i].userType;
                  $scope.profileImage=$scope.userList[i].image;
             
                 $scope.gender=$scope.userList[i].gender;

                 $scope.identityNumber=$scope.userList[i].identityNumber;
                 $scope.primaryEmail=$scope.userList[i].primaryEmail;
                 $scope.alternateEmail=$scope.userList[i].alternateEmail;
                 $scope.primaryMobileNo=$scope.userList[i].primaryMobileNo;
                 $scope.alternateMobileNo=$scope.userList[i].alternateMobileNo;
                 $scope.country=$scope.userList[i].country;
                 $scope.state=$scope.userList[i].state;
                 $scope.city=$scope.userList[i].city;
                 $scope.zipcode=$scope.userList[i].zipcode;
                 $scope.address=$scope.userList[i].address;
                 for(var j=0;j<$scope.userList[i].workPackage.length;j++)
                    {
                	 for(var k=0;k<$scope.example6data.length;k++)
                		 {
                		 if($scope.example6data[k].id==$scope.userList[i].workPackage[j].workPackageId)
                			 {
                		
                			 $scope.example6model.push($scope.example6data[k]);	 
                			 }
                		 }
  
                        

                    }
           
                   for(var j=0;j<$scope.userList[i].contractors.length;j++)
                    {
   $scope.contractorId=$scope.userList[i].contractors[j].contractorId;
                     /* $scope.contractorsmultiobj={};
                        $scope.contractorsmultiobj.id=$scope.userList[i].contractors[j].contractorId;
                        $scope.contractorsmultiobj.label=$scope.userList[i].contractors[j].name;
                          $scope.contractorsmultiselect.push($scope.workPackagemultiobj);*/

                    }
                    for(var j=0;j<$scope.userList[i].consultancy.length;j++)
                    {
                      $scope.consultancyId=$scope.userList[i].consultancy[j].consultancyId;
                   /*   $scope.consultancymultiobj={};
                        $scope.consultancymultiobj.id=$scope.userList[i].consultancy[j].workPackageId;
                        $scope.consultancymultiobj.label=$scope.userList[i].consultancy[j].name;
                          $scope.consultancymultiselect.push($scope.consultancymultiobj);*/
                    }
                 for(var j=0;j<$scope.userList[i].userOrganizations.length;j++)
                 {
              	

                   if($scope.userList[i].userOrganizations[j].orglevelType=="Orgnization")
                   {

                     $scope.orgId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="BusinessUnit")
                   {

                     $scope.businessunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectType")
                   {

                     $scope.projecttypeId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectSite")
                   {
                     $scope.projectsiteId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectPhase")
                   {
                     $scope.projectphaseId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingType")
                   {
                     $scope.buildingtypeId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingFloor")
                   {
                     $scope.buildingfloorId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingUnit")
                   {
                     $scope.buildingunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }
                   if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingSubUnit")
                   {
                     $scope.buildingsubunitunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                   }


                 }

              }
          }
          $rootScope.isTrascError = false;
          $('div').removeClass('has-error edited');
          $('input').removeClass('form-control').addClass('form-control edited');
          $('textarea').removeClass('form-control').addClass('form-control edited');
          $('select').removeClass('form-control').addClass('form-control edited');
          $('#user-model').modal('show');
      				}
        $scope.viewUser=function(value)
                {

                            $scope.isView = true;
                          	$scope.headername = "View User Profile";
                            $scope.profileImage="";
                            $scope.username="";
                            $scope.password="";
                            $scope.roleId ="";
                            $scope.fullName="";
                            $scope.dob="";
                            $scope.userType="";
                            $scope.gender="";
                            $scope.identityNumber="";
                            $scope.primaryEmail="";
                            $scope.alternateEmail="";
                            $scope.primaryMobileNo="";
                            $scope.alternateMobileNo="";
                            $scope.country="";
                            $scope.state="";
                            $scope.city="";
                            $scope.zipcode="";
                            $scope.address="";
                            $scope.orgId=null;
                            $scope.businessunitId=null;
                            $scope.projecttypeId=null;
                            $scope.projectsiteId=null;
                            $scope.projectphaseId=null;
                            $scope.projectsiteId=null;
                            $scope.projectphaseId=null;
                            $scope.buildingtypeId=null;
                            $scope.buildingfloorId=null;
                            $scope.buildingunitId=null;
                            $scope.buildingsubunitunitId=null;
                            $scope.consultancyId=null;
                            $scope.workpackageId=null;
                            $scope.contractorId=null;
                            $scope.example6model=[];
                            for(var i=0;i<$scope.userList.length;i++)
                            {
                                if ($scope.userList[i].userId==value)
                                 {

                                  $scope.userId=$scope.userList[i].userId;
                                   $scope.username=$scope.userList[i].username;
                                   $scope.password=window.atob($scope.userList[i].password);
                                   $scope.roleId =$scope.userList[i].roleId;
                                   $scope.fullName=$scope.userList[i].fullName;
                                   $scope.dob=$scope.userList[i].dob;
                                   $scope.userType=$scope.userList[i].userType;
                                    $scope.profileImage=$scope.userList[i].image;
                               
                                   $scope.gender=$scope.userList[i].gender;
       
                                   $scope.identityNumber=$scope.userList[i].identityNumber;
                                   $scope.primaryEmail=$scope.userList[i].primaryEmail;
                                   $scope.alternateEmail=$scope.userList[i].alternateEmail;
                                   $scope.primaryMobileNo=$scope.userList[i].primaryMobileNo;
                                   $scope.alternateMobileNo=$scope.userList[i].alternateMobileNo;
                                   $scope.country=$scope.userList[i].country;
                                   $scope.state=$scope.userList[i].state;
                                   $scope.city=$scope.userList[i].city;
                                   $scope.zipcode=$scope.userList[i].zipcode;
                                   $scope.address=$scope.userList[i].address;
                                   for(var j=0;j<$scope.userList[i].workPackage.length;j++)
                                   {
                               	 for(var k=0;k<$scope.example6data.length;k++)
                               		 {
                               		 if($scope.example6data[k].id==$scope.userList[i].workPackage[j].workPackageId)
                               			 {
                               		
                               			 $scope.example6model.push($scope.example6data[k]);	 
                               			 }
                               		 }
                 
                                       

                                   }
                                     for(var j=0;j<$scope.userList[i].contractors.length;j++)
                                      {
                     $scope.contractorId=$scope.userList[i].contractors[j].contractorId;
                                       /* $scope.contractorsmultiobj={};
                                          $scope.contractorsmultiobj.id=$scope.userList[i].contractors[j].contractorId;
                                          $scope.contractorsmultiobj.label=$scope.userList[i].contractors[j].name;
                                            $scope.contractorsmultiselect.push($scope.workPackagemultiobj);*/

                                      }
                                      for(var j=0;j<$scope.userList[i].consultancy.length;j++)
                                      {
                                        $scope.consultancyId=$scope.userList[i].consultancy[j].consultancyId;
                                     /*   $scope.consultancymultiobj={};
                                          $scope.consultancymultiobj.id=$scope.userList[i].consultancy[j].workPackageId;
                                          $scope.consultancymultiobj.label=$scope.userList[i].consultancy[j].name;
                                            $scope.consultancymultiselect.push($scope.consultancymultiobj);*/
                                      }
                                   for(var j=0;j<$scope.userList[i].userOrganizations.length;j++)
                                   {
                                	

                                     if($scope.userList[i].userOrganizations[j].orglevelType=="Orgnization")
                                     {

                                       $scope.orgId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="BusinessUnit")
                                     {

                                       $scope.businessunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectType")
                                     {

                                       $scope.projecttypeId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectSite")
                                     {
                                       $scope.projectsiteId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="ProjectPhase")
                                     {
                                       $scope.projectphaseId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingType")
                                     {
                                       $scope.buildingtypeId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingFloor")
                                     {
                                       $scope.buildingfloorId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingUnit")
                                     {
                                       $scope.buildingunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }
                                     if($scope.userList[i].userOrganizations[j].orglevelType=="BuildingSubUnit")
                                     {
                                       $scope.buildingsubunitunitId=$scope.userList[i].userOrganizations[j].orglevelId;
                                     }


                                   }

                                }
                            }




                  $rootScope.isTrascError = false;
                  $('div').removeClass('has-error edited');
                  $('input').removeClass('form-control').addClass('form-control edited');
                  $('textarea').removeClass('form-control').addClass('form-control edited');
                  $('select').removeClass('form-control').addClass('form-control edited');
                  $('#user-model').modal('show');
                      }
        $scope.getsubunitbyid = function(value) {

      	  var headers = {
      			    'BuildingUnitId':value,
      			  'Auth_Token':$rootScope.globals.userDTO.token
      			  }

      	  var config={
      			  headers:headers
      	  }

      	userService.getAllBuildingSubUnitsbyBUId(config).then(function (data) {
                 $scope.buildingSubUnitList= data.data.objects;

  });

        }

                      $scope.saveUser = function (username,password,roleId,fullName,dob,userType,gender,identityNumber,primaryEmail,alternateEmail,primaryMobileNo,alternateMobileNo,country,state,city,zipcode,address,orgId,businessunitId,projecttypeId,projectsiteId,projectphaseId,buildingtypeId,buildingfloorId,buildingunitId,buildingsubunitunitId,consultancyId,contractorId,workpackagelist) {

                        var user={};
                        var consultancy=[];
                        var  consultancyobj={};
                        var workPackage=[];
                        var workPackageobj={};
                        var contractors=[];
                        var contractorsobj={};
                        var organization=[];
                        var organizationobj={};
                        var businessunit=[];
                        var businessunitobj={};
                        var projecttype=[];
                        var projecttypeobj={};
                        var projectsite=[];
                        var projectsiteobj={};
                        var projectphase=[];
                        var projectphaseobj={};
                        var buildingtype=[];
                        var buildingtypeobj={};
                        var buildingfloor=[];
                        var buildingfloorobj={};
                        var buildingunit=[];
                        var buildingunitobj={};
                        var buildingsubunit=[];
                        var buildingsubunitobj={};
                        var userId=$scope.userId;
                        user.consultancy=[];
                        user.workPackage=[];
                        user.contractors=[];
                        user.organization=[];
                        user.businessunit=[];
                        user.projecttype=[];
                        user.projectsite=[];
                        user.projectphase=[];
                        user.buildingtype=[];
                        user.buildingfloor=[];
                        user.buildingunit=[];
                        user.buildingsubunit=[];
                     
                        user.username=username;
 	                      user.password=window.btoa(password);
 	                      user.roleId=roleId;
 	                      user.fullName=fullName;
 	                   //  $scope.datavalue = JSON.stringify(workpackagelist);
 	                   //  alert( $scope.datavalue);
 	                   
 	                  if(dob ==null || dob==undefined || dob=="")
	{
 	   user.dob=null;                 
	}
else
	{
	  user.dob=dob;
	}
if(gender ==null ||gender == undefined || gender =="")
	{
    user.gender="M";
	}
else
	{
	 user.gender=gender;
	}

 	                      user.userType=userType;
                     
                        user.identityNumber=identityNumber;
                     	  user.primaryEmail=primaryEmail;
                     	  user.alternateEmail=alternateEmail;
                     	  user.primaryMobileNo=primaryMobileNo;
                     	  user.alternateMobileNo=alternateMobileNo;

                     	  user.country=country;
                     	  user.state=state;
                     	  user.city=city;
                     	  user.zipcode=zipcode;
                     	  user.address=address;

                  if(consultancyId !=null || consultancyId !=undefined)
                  {
                        consultancyobj.consultancyId=consultancyId;

                        user.consultancy.push(consultancyobj);
                   }

                  /* if(workpackageId !=null || workpackageId !=undefined)
                  {
                        workPackageobj.workPackageId=workpackageId;
                        user.workPackage.push(workPackageobj);
                  }*/
               
                  if($scope.example6model.length >0)
                	  {
for(var i=0;i<$scope.example6model.length ;i++)
	{
	workPackageobj={};
	  workPackageobj.workPackageId=$scope.example6model[i].id;
      user.workPackage.push(workPackageobj);
	}
                	  }
                  if(contractorId !=null || contractorId !=undefined)
                  {
                        contractorsobj.contractorId=contractorId;
                        user.contractors.push(contractorsobj);
                  }

                  if(orgId !=null || orgId !=undefined)
                  {
                        organizationobj.organizationId=orgId;
                        user.organization.push(organizationobj);
                  }

                  if(businessunitId !=null || businessunitId !=undefined)
                  {
                        businessunitobj.businessUnitId=businessunitId;
                        user.businessunit.push(businessunitobj);
                  }

                  if(projecttypeId !=null || projecttypeId !=undefined || projecttypeId)
                  {
                        projecttypeobj.projectTypeId=projecttypeId;
                        user.projecttype.push(projecttypeobj);
                  }

                  if(projectsiteId !=null || projectsiteId !=undefined)
                  {
                        projectsiteobj.projectSiteId=projectsiteId;
                        user.projectsite.push(projectsiteobj);
                  }

                  if(projectphaseId !=null || projectphaseId !=undefined)
                  {
                        projectphaseobj.projectPhaseId=projectphaseId;

                        user.projectphase.push(projectphaseobj);

                  }

                  if(buildingtypeId !=null || buildingtypeId !=undefined)
                  {
                        buildingtypeobj.buildingTypeId=buildingtypeId;
                        user.buildingtype.push(buildingtypeobj);
                  }

                  if(buildingfloorId !=null || buildingfloorId !=undefined)
                  {
                        buildingfloorobj.buildingFloorId=buildingfloorId;
                        user.buildingfloor.push(buildingfloorobj);
                  }

                  if(buildingunitId !=null || buildingunitId !=undefined)
                  {
                        buildingunitobj.buildingUnitId=buildingunitId;
                        user.buildingunit.push(buildingunitobj);
                  }

                  if(buildingsubunitunitId !=null || buildingsubunitunitId !=undefined)
                  {
                        buildingsubunitobj.buildingSubUnitId=buildingsubunitunitId;
                        user.buildingsubunit.push(buildingsubunitobj);
                  }

if(primaryMobileNo ==undefined)
	{
	primaryMobileNo="";
	}
if(alternateMobileNo==undefined)
	{
	alternateMobileNo="";
	}

if($scope.profileImage !=null || $scope.profileImage !=undefined)
{
  var str = $scope.profileImage;
  var res = str.split(",");

  user.imageContent=res[1];
  user.extension="jpg";
}

                        $scope.continuesave = true;

                            if (!username || username==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter User Name");
                                 $scope.continuesave = false;
                             } else if (!password || password==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Password");
                                 $scope.continuesave = false;
                             } else if (!roleId || roleId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Role");
                                 $scope.continuesave = false;
                             }else if (primaryMobileNo.length>10 || primaryMobileNo.length<10 && primaryMobileNo!="" ) {
                           
                            		     
                            		    	  $rootScope.isTrascError = true;
                                              FlashService.Error("Please Enter correct Primary Mobile Number");
                                              $scope.continuesave = false;
                            		   
                                
                             }
                            /* else if(primaryMobileNo.length ==10)
                            	 {
                            	 
                             	 if(primaryMobileNo.match(phoneno))  
                             		        {  
                             		    
                             		        }  
                             		      else  
                             		        {  
                             		    	  $rootScope.isTrascError = true;
                                               FlashService.Error("Please Enter correct Primary Mobile Number");
                                               $scope.continuesave = false;
                             		        }  
                            	 }*/
                            
                             else if (alternateMobileNo.length>10 || alternateMobileNo.length<10 && alternateMobileNo!="") {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter correct Alternate Mobile Number");
                                 $scope.continuesave = false;
                             }
                           /*  else if(alternateMobileNo.length ==10)
                        	 {
                        	 alert("in this");
                         	 if(alternateMobileNo.match(phoneno))  
                         		        {  
                         		   
                         		        }  
                         		      else  
                         		        {  
                         		    	  $rootScope.isTrascError = true;
                                           FlashService.Error("Please Enter correct Alternate Mobile Number");
                                           $scope.continuesave = false;
                         		        }  
                        	 }*/
                              else if (!fullName || fullName==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Fullname");
                                 $scope.continuesave = false;
                             }
                             else if (!userType || userType==undefined) {

                                $rootScope.isTrascError = true;
                                FlashService.Error("Please Select User Type");
                                $scope.continuesave = false;
                            }
                            else if(userType=="External")
                            {
                              if(!consultancyId || consultancyId==undefined || !consultancyId || consultancyId==undefined)
                              {
                                $rootScope.isTrascError = true;
                                FlashService.Error("Please Select contractor and consultancy");
                                $scope.continuesave = false;
                              }
                            }
                            else if(userType=="Internal")
                            	{
                            	  user.consultancy=[];
                                  user.contractors=[];
                            	}
                             else if (!orgId || orgId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Organization");
                                 $scope.continuesave = false;
                             }
                             else if (!businessunitId || businessunitId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select BusinessUnit");
                                 $scope.continuesave = false;
                             }
                             else if (!projecttypeId || projecttypeId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Project Type");
                                 $scope.continuesave = false;
                             }
                             else if (!projectsiteId || projectsiteId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Project Site");
                                 $scope.continuesave = false;
                             }
                          /*   else if (!workpackageId || workpackageId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Work Package");
                                 $scope.continuesave = false;
                             }*/
                            
                             else if ($scope.example6model.length==0) {
                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Work Package");
                                 $scope.continuesave = false;
                             }

                              else {
                                 $scope.continuesave = true;
                                 $rootScope.isTrascError = false;
                             }
                             if(primaryMobileNo.length ==10)
                       	 {
                       	 
                        	 if(primaryMobileNo.match(phoneno))  
                        		        {  
                        		    
                        		        }  
                        		      else  
                        		        {  
                        		    	  $rootScope.isTrascError = true;
                                          FlashService.Error("Please Enter correct Primary Mobile Number");
                                          $scope.continuesave = false;
                        		        }  
                       	 }
                             if(alternateMobileNo.length ==10)
                        	 {
                        	
                         	 if(alternateMobileNo.match(phoneno))  
                         		        {  
                         		   
                         		        }  
                         		      else  
                         		        {  
                         		    	  $rootScope.isTrascError = true;
                                           FlashService.Error("Please Enter correct Alternate Mobile Number");
                                           $scope.continuesave = false;
                         		        }  
                        	 }
                          
                             if(primaryEmail !="" )
                            	 {
                            
                            	
                            	 if(primaryEmail.match(mailformat))  
                            	 {  
                            	
                            	 }  
                            	 else  
                            	 {  
                            		  $rootScope.isTrascError = true;
                                      FlashService.Error("Please Enter correct Primary Email Id");
                                      $scope.continuesave = false;
                            	 }  
                            	 }
                             if( alternateEmail !="" )
                        	 {
                              
                        	 if(alternateEmail.match(mailformat))  
                        	 {  
                        	
                        	 }  
                        	 else  
                        	 {  
                        		  $rootScope.isTrascError = true;
                                  FlashService.Error("Please Enter correct Alternate Email Id");
                                  $scope.continuesave = false;
                        	 }  
                        	 }
                            if ($scope.continuesave) {

                                 if (!userId) {
                                	user.createdBy= $rootScope.globals.userDTO.userId;
                                     userService
                                             .saveUser(user)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 201) {

                                                             $('#user-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 } else {

                                   user.userId=userId;
                               	user.updatedBy= $rootScope.globals.userDTO.userId;
                                    userService
                                             .updateUser(user)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 200) {
                                                             $('#user-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 }
                             }
                      }

                      $scope.imageUpload = function(event){
                          var files = event.target.files; //FileList object

                        for (var i = 0; i < files.length; i++) {
                            if(files[i].name.toLowerCase().includes(".jpg") || files[i].name.toLowerCase().includes(".jpeg") || files[i].name.toLowerCase().includes(".png")){
                               var file = files[i];
                                     var reader = new FileReader();
                                     reader.onload = $scope.imageIsLoaded;
                                     reader.readAsDataURL(file);
                                     $scope.imgErrorMsg = false;
                               }else{
                                 $scope.imgErrorMsg = true;
                               }
                          }
                     };
                     $scope.imageIsLoaded = function(e){
                         $scope.$apply(function() {
                             $scope.profileImage = e.target.result;
                            
                         });
                     };
function workpackagemultiselect(){
	
	
	 for(var j=0;j<$scope.workPackageList.length;j++)
     {
		 $scope.workPackagemultiobj={};
//     $scope.workpackageId=$scope.userList[i].workPackage[j].workPackageId;
	      $scope.workPackagemultiobj.label=  $scope.workPackageList[j].name;
         $scope.workPackagemultiobj.id=  $scope.workPackageList[j].workPackageId;
   
           $scope.workPackagemultiselect.push($scope.workPackagemultiobj);

     }
	
	   
        $scope.myJsonString = JSON.stringify($scope.workPackagemultiselect);
    
       $scope.example14data.push($scope.myJsonString);
}

            }]);
var directiveModule = angular.module('angularjs-dropdown-multiselect', []);

directiveModule.directive('ngDropdownMultiselect', ['$filter', '$document', '$compile', '$parse',

function ($filter, $document, $compile, $parse) {

    return {
        restrict: 'AE',
        scope: {
            selectedModel: '=',
            options: '=',
            extraSettings: '=',
            events: '=',
            searchFilter: '=?',
            translationTexts: '=',
            groupBy: '@'
        },
        template: function (element, attrs) {
            var checkboxes = attrs.checkboxes ? true : false;
            var groups = attrs.groupBy ? true : false;

            var template = '<div class="multiselect-parent btn-group dropdown-multiselect">';
            template += '<button type="button" class="dropdown-toggle" ng-class="settings.buttonClasses" ng-click="toggleDropdown()">{{getButtonText()}}&nbsp;<span class="caret"></span></button>';
            template += '<ul class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? \'block\' : \'none\', height : settings.scrollable ? settings.scrollableHeight : \'auto\' }" style="overflow: scroll" >';
            template += '<li ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()"><span class="glyphicon glyphicon-ok"></span>  {{texts.checkAll}}</a>';
            template += '<li ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();"><span class="glyphicon glyphicon-remove"></span>   {{texts.uncheckAll}}</a></li>';
            template += '<li ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) && !settings.showUncheckAll" class="divider"></li>';
            template += '<li ng-show="settings.enableSearch"><div class="dropdown-header"><input type="text" class="form-control" style="width: 100%;" ng-model="searchFilter" placeholder="{{texts.searchPlaceholder}}" /></li>';
            template += '<li ng-show="settings.enableSearch" class="divider"></li>';

            if (groups) {
                template += '<li ng-repeat-start="option in orderedItems | filter: searchFilter" ng-show="getPropertyForObject(option, settings.groupBy) !== getPropertyForObject(orderedItems[$index - 1], settings.groupBy)" role="presentation" class="dropdown-header">{{ getGroupTitle(getPropertyForObject(option, settings.groupBy)) }}</li>';
                template += '<li ng-repeat-end role="presentation">';
            } else {
                template += '<li role="presentation" ng-repeat="option in options | filter: searchFilter">';
            }

            template += '<a role="menuitem" tabindex="-1" ng-click="setSelectedItem(getPropertyForObject(option,settings.idProp))">';

            if (checkboxes) {
                template += '<div class="checkbox"><label><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.idProp))" ng-checked="isChecked(getPropertyForObject(option,settings.idProp))" /> {{getPropertyForObject(option, settings.displayProp)}}</label></div></a>';
            } else {
                template += '<span data-ng-class="{\'glyphicon glyphicon-ok\': isChecked(getPropertyForObject(option,settings.idProp))}"></span> {{getPropertyForObject(option, settings.displayProp)}}</a>';
            }

            template += '</li>';

            template += '<li class="divider" ng-show="settings.selectionLimit > 1"></li>';
            template += '<li role="presentation" ng-show="settings.selectionLimit > 1"><a role="menuitem">{{selectedModel.length}} {{texts.selectionOf}} {{settings.selectionLimit}} {{texts.selectionCount}}</a></li>';

            template += '</ul>';
            template += '</div>';

            element.html(template);
        },
        link: function ($scope, $element, $attrs) {
            var $dropdownTrigger = $element.children()[0];

            $scope.toggleDropdown = function () {
                $scope.open = !$scope.open;
            };

            $scope.checkboxClick = function ($event, id) {
                $scope.setSelectedItem(id);
                $event.stopImmediatePropagation();
            };

            $scope.externalEvents = {
                onItemSelect: angular.noop,
                onItemDeselect: angular.noop,
                onSelectAll: angular.noop,
                onDeselectAll: angular.noop,
                onInitDone: angular.noop,
                onMaxSelectionReached: angular.noop
            };

            $scope.settings = {
                dynamicTitle: true,
                scrollable: true,
                scrollableHeight: '300px',
                closeOnBlur: true,
                displayProp: 'label',
                idProp: 'id',
                externalIdProp: 'id',
                enableSearch: true,
                selectionLimit: 0,
                showCheckAll: true,
                showUncheckAll: true,
                closeOnSelect: false,
                buttonClasses: 'btn btn-default',
                closeOnDeselect: false,
                groupBy: $attrs.groupBy || undefined,
                groupByTextProvider: null,
                smartButtonMaxItems: 0,
                smartButtonTextConverter: angular.noop
            };

            $scope.texts = {
                checkAll: 'Check All',
                uncheckAll: 'Uncheck All',
                selectionCount: 'Workpackages Selected',
                selectionOf: '/',
                searchPlaceholder: 'Search...',
                buttonDefaultText: 'Workpackage Name',
                dynamicButtonTextSuffix: 'Workpackages Seelcted'
            };

            $scope.searchFilter = $scope.searchFilter || '';

            if (angular.isDefined($scope.settings.groupBy)) {
                $scope.$watch('options', function (newValue) {
                    if (angular.isDefined(newValue)) {
                        $scope.orderedItems = $filter('orderBy')(newValue, $scope.settings.groupBy);
                    }
                });
            }

            angular.extend($scope.settings, $scope.extraSettings || []);
            angular.extend($scope.externalEvents, $scope.events || []);
            angular.extend($scope.texts, $scope.translationTexts);

            $scope.singleSelection = $scope.settings.selectionLimit === 1;

            function getFindObj(id) {
                var findObj = {};

                if ($scope.settings.externalIdProp === '') {
                    findObj[$scope.settings.idProp] = id;
                } else {
                    findObj[$scope.settings.externalIdProp] = id;
                }

                return findObj;
            }

            function clearObject(object) {
                for (var prop in object) {
                    delete object[prop];
                }
            }

            if ($scope.singleSelection) {
                if (angular.isArray($scope.selectedModel) && $scope.selectedModel.length === 0) {
                    clearObject($scope.selectedModel);
                }
            }

            if ($scope.settings.closeOnBlur) {
                $document.on('click', function (e) {
                    var target = e.target.parentElement;
                    var parentFound = false;

                    while (angular.isDefined(target) && target !== null && !parentFound) {
                        if (_.contains(target.className.split(' '), 'multiselect-parent') && !parentFound) {
                            if (target === $dropdownTrigger) {
                                parentFound = true;
                            }
                        }
                        target = target.parentElement;
                    }

                    if (!parentFound) {
                        $scope.$apply(function () {
                            $scope.open = false;
                        });
                    }
                });
            }

            $scope.getGroupTitle = function (groupValue) {
                if ($scope.settings.groupByTextProvider !== null) {
                    return $scope.settings.groupByTextProvider(groupValue);
                }

                return groupValue;
            };

            $scope.getButtonText = function () {
                if ($scope.settings.dynamicTitle && ($scope.selectedModel.length > 0 || (angular.isObject($scope.selectedModel) && _.keys($scope.selectedModel).length > 0))) {
                    if ($scope.settings.smartButtonMaxItems > 0) {
                        var itemsText = [];

                        angular.forEach($scope.options, function (optionItem) {
                            if ($scope.isChecked($scope.getPropertyForObject(optionItem, $scope.settings.idProp))) {
                                var displayText = $scope.getPropertyForObject(optionItem, $scope.settings.displayProp);
                                var converterResponse = $scope.settings.smartButtonTextConverter(displayText, optionItem);

                                itemsText.push(converterResponse ? converterResponse : displayText);
                            }
                        });

                        if ($scope.selectedModel.length > $scope.settings.smartButtonMaxItems) {
                            itemsText = itemsText.slice(0, $scope.settings.smartButtonMaxItems);
                            itemsText.push('...');
                        }

                        return itemsText.join(', ');
                    } else {
                        var totalSelected;

                        if ($scope.singleSelection) {
                            totalSelected = ($scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp])) ? 1 : 0;
                        } else {
                            totalSelected = angular.isDefined($scope.selectedModel) ? $scope.selectedModel.length : 0;
                        }

                        if (totalSelected === 0) {
                            return $scope.texts.buttonDefaultText;
                        } else {
                            return totalSelected + ' ' + $scope.texts.dynamicButtonTextSuffix;
                        }
                    }
                } else {
                    return $scope.texts.buttonDefaultText;
                }
            };

            $scope.getPropertyForObject = function (object, property) {
                if (angular.isDefined(object) && object.hasOwnProperty(property)) {
                    return object[property];
                }

                return '';
            };

            $scope.selectAll = function () {
                $scope.deselectAll(false);
                $scope.externalEvents.onSelectAll();

                angular.forEach($scope.options, function (value) {
                    $scope.setSelectedItem(value[$scope.settings.idProp], true);
                });
            };

            $scope.deselectAll = function (sendEvent) {
                sendEvent = sendEvent || true;

                if (sendEvent) {
                    $scope.externalEvents.onDeselectAll();
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                } else {
                    $scope.selectedModel.splice(0, $scope.selectedModel.length);
                }
            };

            $scope.setSelectedItem = function (id, dontRemove) {
                var findObj = getFindObj(id);
                var finalObj = null;

                if ($scope.settings.externalIdProp === '') {
                    finalObj = _.find($scope.options, findObj);
                } else {
                    finalObj = findObj;
                }

                if ($scope.singleSelection) {
                    clearObject($scope.selectedModel);
                    angular.extend($scope.selectedModel, finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                    if ($scope.settings.closeOnSelect) $scope.open = false;

                    return;
                }

                dontRemove = dontRemove || false;

                var exists = _.findIndex($scope.selectedModel, findObj) !== -1;

                if (!dontRemove && exists) {
                    $scope.selectedModel.splice(_.findIndex($scope.selectedModel, findObj), 1);
                    $scope.externalEvents.onItemDeselect(findObj);
                } else if (!exists && ($scope.settings.selectionLimit === 0 || $scope.selectedModel.length < $scope.settings.selectionLimit)) {
                    $scope.selectedModel.push(finalObj);
                    $scope.externalEvents.onItemSelect(finalObj);
                }
                if ($scope.settings.closeOnSelect) $scope.open = false;
            };

            $scope.isChecked = function (id) {
                if ($scope.singleSelection) {
                    return $scope.selectedModel !== null && angular.isDefined($scope.selectedModel[$scope.settings.idProp]) && $scope.selectedModel[$scope.settings.idProp] === getFindObj(id)[$scope.settings.idProp];
                }

                return _.findIndex($scope.selectedModel, getFindObj(id)) !== -1;
            };

            $scope.externalEvents.onInitDone();
        }
    };
}]);