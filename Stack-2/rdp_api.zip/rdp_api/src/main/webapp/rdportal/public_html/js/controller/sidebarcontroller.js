
'use strict';

angular.module('myApp.sidebarCtrl', [])
        .controller('sidebarCtrl', ['$scope', '$rootScope', '$window', '$location', '$http', '$sessionStorage', function ($scope, $rootScope, $window, $location, $http, $sessionStorage) {
                $scope.slide = '';
                $scope.loginData = {};
                $rootScope.back = function () {
                    $scope.slide = 'slide-right';
                    $window.history.back();
                }
                $rootScope.go = function (path) {
                    $scope.slide = 'slide-left';
                    $location.url(path);
                }
                $rootScope.isheader = false;
                if($rootScope.isLogin==true) {
                    $sessionStorage.Login =true;  
                 }                
                 if($sessionStorage.Login) {
                    $rootScope.isLogin =true;  
                 } else {
                    $rootScope.isLogin =false;
                 }
                 console.log("login contoller sidebar"+ $rootScope.isLogin);
                /*$scope.authenticateUser = function ()
                {
                   
                 $location.path('/lookup');

                }*/
                
                
                $scope.selectNodeLabel=function(node, $event){
                    var url=node.url;
                     var isFolder=node.isFolder;
                     if(!isFolder){
					 $location.path(url);
                    /*if(lableName=='lookup'){
                        $location.path('/lookup');
                    }else if(lableName=='Menu Entries'){
                        alert("You Were Selected "+lableName+" But Currently Link is enabled only for LookUp");
                        $location.path('/lookup');
                    }else if(lableName=='Category'){
                        alert("You Were Selected "+lableName+" But Currently Link is enabled only for LookUp");
                        $location.path('/lookup');
                    }else{
                        alert("Currently Link is enabled only for LookUp");
                        $location.path('/login');
                    }*/
                }
             }


            }]);


